# Build APK hanya dari HP

1. Buat repository GitHub baru (mis. `moyuanmotion-android`).
2. Upload seluruh isi folder project ini ke repository. Folder `.github/workflows/build-apk.yml` harus ikut.
3. Buka tab **Actions** pada repository.
4. Pilih workflow **Build Mo Yuan Motion APK**.
5. Tekan **Run workflow** jika diperlukan.
6. Tunggu sampai selesai (status hijau).
7. Buka hasil run → bagian **Artifacts** → download `MoYuanMotion-debug-apk`.
8. Extract ZIP artifact dan install `app-debug.apk` di HP.

API key OpenRouter tetap dimasukkan oleh masing-masing pengguna di aplikasi; jangan taruh API key di repository.
