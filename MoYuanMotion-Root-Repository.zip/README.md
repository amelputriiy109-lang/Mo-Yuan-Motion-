# Mo Yuan Motion — Android

Android app wrapper with the Mo Yuan Motion interface bundled locally.

## Included visual assets
- `app/src/main/assets/web/images/background.jpg` — default background
- `app/src/main/assets/web/images/avatar.jpg` — default welcome avatar

The app uses the user's own OpenRouter API key. The key is stored in the app's LocalStorage and is not embedded in the APK.

Open the project in Android Studio and build the debug APK with **Build > Build APK(s)**.
