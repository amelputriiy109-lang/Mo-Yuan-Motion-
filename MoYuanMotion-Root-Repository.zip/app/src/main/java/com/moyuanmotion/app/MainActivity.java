package com.moyuanmotion.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " MoYuanMotion/1.0");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(), "MoYuanNative");
        webView.loadUrl("file:///android_asset/web/index.html");
    }

    public class NativeBridge {
        @JavascriptInterface
        public void requestAI(final String requestId, final String baseUrl, final String apiKey,
                              final String model, final String systemPrompt, final String conversationJson) {
            executor.execute(() -> {
                String result;
                try {
                    if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("API Key belum diisi.");
                    if (baseUrl == null || !baseUrl.startsWith("https://")) throw new Exception("Base URL harus menggunakan HTTPS.");

                    JSONArray conversation = new JSONArray(conversationJson);
                    JSONArray messages = new JSONArray();
                    if (systemPrompt != null && !systemPrompt.trim().isEmpty()) {
                        JSONObject sys = new JSONObject(); sys.put("role", "system"); sys.put("content", systemPrompt); messages.put(sys);
                    }
                    for (int i = 0; i < conversation.length(); i++) messages.put(conversation.getJSONObject(i));

                    JSONObject payload = new JSONObject();
                    payload.put("model", model);
                    payload.put("messages", messages);
                    payload.put("temperature", 0.7);
                    payload.put("stream", false);

                    HttpURLConnection c = (HttpURLConnection) new URL(baseUrl).openConnection();
                    c.setRequestMethod("POST");
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(120000);
                    c.setDoOutput(true);
                    c.setRequestProperty("Content-Type", "application/json");
                    c.setRequestProperty("Authorization", "Bearer " + apiKey.trim());
                    c.setRequestProperty("X-Title", "Mo Yuan Motion");
                    byte[] body = payload.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = c.getOutputStream()) { out.write(body); }

                    int code = c.getResponseCode();
                    InputStream stream = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
                    String text = readAll(stream);
                    if (code < 200 || code >= 300) throw new Exception("HTTP " + code + ": " + trim(text, 700));
                    JSONObject data = new JSONObject(text);
                    String answer = data.optJSONArray("choices") != null && data.optJSONArray("choices").length() > 0
                            ? data.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "") : "";
                    if (answer.isEmpty()) throw new Exception("Respons API tidak memiliki isi jawaban.");
                    JSONObject out = new JSONObject(); out.put("ok", true); out.put("answer", answer);
                    result = out.toString();
                    c.disconnect();
                } catch (Exception e) {
                    try { JSONObject out = new JSONObject(); out.put("ok", false); out.put("error", e.getMessage() == null ? e.toString() : e.getMessage()); result = out.toString(); }
                    catch (Exception ignored) { result = "{\"ok\":false,\"error\":\"Terjadi kesalahan.\"}"; }
                }
                final String js = "window.__nativeAIResult(" + JSONObject.quote(requestId) + "," + JSONObject.quote(result) + ");";
                main.post(() -> webView.evaluateJavascript(js, null));
            });
        }

        @JavascriptInterface public void toast(final String message) {
            main.post(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
        }
    }

    private static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while ((line = r.readLine()) != null) b.append(line);
        }
        return b.toString();
    }
    private static String trim(String s, int max) { return s == null ? "" : (s.length() <= max ? s : s.substring(0, max)); }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { executor.shutdownNow(); if (webView != null) webView.destroy(); super.onDestroy(); }
}
